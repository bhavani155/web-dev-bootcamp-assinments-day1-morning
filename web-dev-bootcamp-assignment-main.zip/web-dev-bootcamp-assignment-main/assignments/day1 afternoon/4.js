function fun() {
	document.getElementById("p").style.color="red";
}